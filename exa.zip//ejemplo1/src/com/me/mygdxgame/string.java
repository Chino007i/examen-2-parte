package com.me.mygdxgame;

public class string {

}
