package com.me.mygdxgame;

public class ejemplo {

}
